/*
============================================
; Title: Assignment 3.2
; Author: Chris Harris
; Date: 4 April 2021
; Description: Week 3 product.js file.
; 
;===========================================
*/
export class Product{
    constructor(name, price)
    {
        this.name = name;
        this.price = price;
    }
}